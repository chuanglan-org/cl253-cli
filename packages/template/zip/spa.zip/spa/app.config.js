// 更多配置信息 https://github.com/chuanglan-org/cl253-cli/blob/master/docs/appConfig.md
module.exports = {
  port: 8081,
  devOpen: false,
  Analyze: false,
  buildZip: true,
};
