import React from "react";
import { createFromIconfontCN } from "@ant-design/icons";
export default createFromIconfontCN({
  scriptUrl: "//at.alicdn.com/t/c/font_1359323_xxhs6ncsyda.js",
});
