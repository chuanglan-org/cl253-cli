import React from "react";
import { createFromIconfontCN } from "@ant-design/icons";
export default createFromIconfontCN({
  scriptUrl: "//at.alicdn.com/t/font_3201091_fglaijrzzye.js",
});
