### 欢迎使用cl253 独立react模板

本地开发使用命令 `npm run dev`

生成环境命令 `npm run build`

所有配置在根文件app.config.js中配置
